import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { ArrowRight, ExternalLink, Menu, RotateCcw, X } from 'lucide-react';
import { CODE, PAPER, PDF, sections } from './content';
import { Results, SearchLab } from './components/Interactions';
import { CupMemoryLab, DecisionLab, DetailLab, SealPipeline } from './components/StoryInteractions';

const STORAGE = 'vstar-progressive-learning-v3';
const PREVIOUS_STORAGE = 'vstar-progressive-learning-v2';
const LEGACY_STORAGE = 'vstar-seven-chapters-v1';
const CHAPTERS = sections.length;
type LearningProgress = { unlockedThrough: number; completedThrough: number; visited: string[]; reviewUnlocked: boolean };
const initialProgress: LearningProgress = { unlockedThrough: 0, completedThrough: 0, visited: [], reviewUnlocked: false };
function savedProgress(): LearningProgress {
  try {
    const current = localStorage.getItem(STORAGE);
    const stored = current ?? localStorage.getItem(PREVIOUS_STORAGE);
    if (!stored) return initialProgress;
    const value: unknown = JSON.parse(stored);
    if (!value || typeof value !== 'object') return initialProgress;
    const progress = value as Partial<LearningProgress>;
    const legacy = current === null;
    const oldMax = legacy ? 7 : CHAPTERS;
    const oldUnlocked = progress.unlockedThrough;
    const oldCompleted = progress.completedThrough;
    if (!Number.isInteger(oldUnlocked) || oldUnlocked! < 0 || oldUnlocked! > oldMax ||
        !Number.isInteger(oldCompleted) || oldCompleted! < 0 || oldCompleted! > oldUnlocked!) return initialProgress;
    // The former §3 Overview now lives inside §2; preserve only milestones the reader reached.
    const unlockedThrough = legacy ? [0, 1, 2, 2, 3, 4, 5, 6][oldUnlocked!] : oldUnlocked!;
    const completedThrough = legacy ? [0, 1, 1, 2, 3, 4, 5, 6][oldCompleted!] : oldCompleted!;
    if (!Number.isInteger(unlockedThrough) || unlockedThrough! < 0 || unlockedThrough! > CHAPTERS ||
        !Number.isInteger(completedThrough) || completedThrough! < 0 || completedThrough! > unlockedThrough!) return initialProgress;
    const allowed = new Set<string>(sections.slice(0, unlockedThrough).map(([id]) => id));
    const visited = Array.isArray(progress.visited) ? progress.visited.filter((id): id is string => typeof id === 'string' && allowed.has(id)) : [];
    const reviewUnlocked = completedThrough === CHAPTERS && progress.reviewUnlocked === true;
    return { unlockedThrough: unlockedThrough!, completedThrough: completedThrough!, visited: [...new Set(visited)], reviewUnlocked };
  } catch { return initialProgress; }
}

function Chapter({ index, children, takeaway, bridge, source, finish }: { index: number; children: ReactNode; takeaway: string; bridge: string; source: string; finish: () => void }) {
  const [id, title, question] = sections[index];
  return <section id={id} className="chapter" aria-labelledby={`${id}-title`}>
    <header className="paper-section-header">
      <h2 id={`${id}-title`} tabIndex={-1} className="chap-title"><span className="num">§{index + 1}.</span>{title}</h2>
      <p className="chapter-question">{question}</p>
      <p className="chapter-thesis">{takeaway}</p>
      <span className="chapter-source">论文依据 · {source}</span>
      <div className="flow-mini" aria-label={`章节进度：第 ${index + 1} 章，共 ${CHAPTERS} 章`}>{sections.map(([sectionId], step) => <span className="flow-piece" key={sectionId}>{step > 0 && <span className="flow-arrow" aria-hidden="true">→</span>}<span className={`flow-step ${step < index ? 'done' : step === index ? 'active' : ''}`} aria-current={step === index ? 'step' : undefined}>§{step + 1}</span></span>)}</div>
    </header>
    <div className="section-body">{children}</div>
    <div className="chapter-bridge"><span>接下来的问题</span><p>{bridge}</p></div>
    <div className="lesson-footer"><button onClick={finish}>{index === CHAPTERS - 1 ? '进入回顾与自测' : `继续学习 §${index + 2}`} <ArrowRight size={18}/></button></div>
  </section>;
}

const quiz = [
  { question: '当前全局视觉信息足够时，SEAL 会怎样做？', answers: ['直接回答', '必须先搜索', '随机裁图'], correct: 0, why: 'Algorithm 1 中，搜索只在当前信息不足时启动。' },
  { question: 'V* 用什么决定优先检查区域？', answers: ['固定从左上开始', '目标或上下文线索', '只按图块面积'], correct: 1, why: '线索热图用于给子图像安排搜索优先级。' },
  { question: 'VWM 中与新证据一起保留什么？', answers: ['跨任务长期记忆', '网页浏览历史', '问题、全图及目标位置'], correct: 2, why: '论文的四块工作输入是 question、global image、searched targets、target location。' },
] as const;
function FinalQuiz() {
  const [answers, setAnswers] = useState<(number | null)[]>([null, null, null]);
  return <div className="final-quiz"><h3>三个问题，检查是否串起了这条路径</h3>{quiz.map((item, i) => <fieldset key={item.question}><legend>{i + 1}. {item.question}</legend><div className="quiz-options">{item.answers.map((answer, j) => <button key={answer} type="button" aria-pressed={answers[i] === j} className={answers[i] === j ? 'selected' : ''} onClick={() => setAnswers(current => current.map((value, index) => index === i ? j : value))}>{answer}</button>)}</div>{answers[i] !== null && <p role="status" className={answers[i] === item.correct ? 'quiz-correct' : 'quiz-review'}>{answers[i] === item.correct ? '答对了。' : '再想想。'}{item.why}</p>}</fieldset>)}</div>;
}

export default function App() {
  const [progress, setProgress] = useState(savedProgress);
  const [active, setActive] = useState('top');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [epoch, setEpoch] = useState(0);
  const [destination, setDestination] = useState('');
  const menu = useRef<HTMLButtonElement>(null);
  const nav = useRef<HTMLElement>(null);
  const visibleCount = progress.unlockedThrough;
  const finalVisible = progress.reviewUnlocked;
  function navigate(id: string) {
    if (id !== 'top' && id !== 'final' && !sections.slice(0, visibleCount).some(([sectionId]) => sectionId === id)) return;
    if (id === 'final' && !finalVisible) return;
    setMobileOpen(false);
    setActive(id);
    if (id !== 'top' && id !== 'final') setProgress(current => current.visited.includes(id) ? current : { ...current, visited: [...current.visited, id] });
    setDestination(id);
  }
  function start() {
    setProgress(current => ({ ...current, unlockedThrough: Math.max(current.unlockedThrough, 1), visited: current.visited.includes(sections[0][0]) ? current.visited : [...current.visited, sections[0][0]] }));
    setActive(sections[0][0]);
    setDestination(sections[0][0]);
  }
  function startReview() { if (finalVisible) navigate(sections[0][0]); }
  function reset() {
    try { localStorage.removeItem(STORAGE); localStorage.removeItem(LEGACY_STORAGE); localStorage.removeItem(PREVIOUS_STORAGE); } catch { /* Reset still works in memory. */ }
    if (window.location.hash) window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}`);
    setProgress(initialProgress);
    setEpoch(e => e + 1);
    navigate('top');
  }
  function advance(index: number) {
    const next = index === CHAPTERS - 1 ? 'final' : sections[index + 1][0];
    setProgress(current => {
      if (index >= current.unlockedThrough) return current;
      const unlockedThrough = Math.max(current.unlockedThrough, Math.min(CHAPTERS, index + 2));
      return { ...current, unlockedThrough, completedThrough: Math.max(current.completedThrough, index + 1),
        reviewUnlocked: current.reviewUnlocked || index === CHAPTERS - 1,
        visited: next === 'final' || current.visited.includes(next) ? current.visited : [...current.visited, next] };
    });
    setMobileOpen(false);
    setActive(next);
    setDestination(next);
  }
  useEffect(() => {
    try {
      if (progress.unlockedThrough === 0) localStorage.removeItem(STORAGE);
      else localStorage.setItem(STORAGE, JSON.stringify(progress));
    } catch { /* Reading stays usable without storage. */ }
  }, [progress]);
  useEffect(() => {
    if (window.location.hash) window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}`);
  }, []);
  useEffect(() => {
    if (!destination) return;
    const frame = requestAnimationFrame(() => {
      const el = document.getElementById(destination);
      if (el) { el.scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth', block: 'start' }); el.querySelector<HTMLElement>('h1, h2')?.focus({ preventScroll: true }); }
      setDestination('');
    });
    return () => cancelAnimationFrame(frame);
  }, [destination, visibleCount, finalVisible]);
  useEffect(() => {
    const observer = new IntersectionObserver(entries => { for (const e of entries) if (e.isIntersecting) setActive(e.target.id); }, { rootMargin: '-5% 0px -65% 0px' });
    document.querySelectorAll('.chapter, .hero, .final').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, [visibleCount, finalVisible]);
  useEffect(() => {
    if (!mobileOpen) return;
    nav.current?.querySelector<HTMLElement>('button:not(:disabled)')?.focus();
    const old = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setMobileOpen(false); menu.current?.focus(); }
      if (event.key === 'Tab') {
        const focusable = nav.current?.querySelectorAll<HTMLElement>('button:not(:disabled), a[href]');
        if (!focusable?.length) return;
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    const onResize = () => { if (window.innerWidth > 1024) setMobileOpen(false); };
    window.addEventListener('keydown', onKey); window.addEventListener('resize', onResize);
    return () => { document.body.style.overflow = old; window.removeEventListener('keydown', onKey); window.removeEventListener('resize', onResize); };
  }, [mobileOpen]);
  return <div className="app-shell">
    <a className="skip-link" href="#top">跳到正文</a>
    <div className="reading-progress" role="progressbar" aria-label="章节解锁进度" aria-valuemin={0} aria-valuemax={CHAPTERS} aria-valuenow={visibleCount} aria-valuetext={`${visibleCount} / ${CHAPTERS} 章已解锁`} style={{width:`${visibleCount / CHAPTERS * 100}%`}}/>
    <button ref={menu} className="mobile-menu" onClick={() => setMobileOpen(true)} aria-label="打开章节导航" aria-expanded={mobileOpen} aria-controls="chapter-sidebar"><Menu size={20}/></button>
    <aside id="chapter-sidebar" ref={nav} className={`sidebar learning-sidebar ${mobileOpen ? 'open' : ''}`} role={mobileOpen ? 'dialog' : undefined} aria-modal={mobileOpen || undefined} aria-label="学习导航">
      <div className="sidebar-brand"><span className="rec-dot" aria-hidden="true"/><div><b>V* PAPERSKILL</b><span>{visibleCount} / {CHAPTERS} 已解锁 · {progress.completedThrough} 已完成</span></div><button onClick={() => { setMobileOpen(false); menu.current?.focus(); }} aria-label="关闭章节导航"><X size={18}/></button></div>
      <nav aria-label="章节导航"><button className={active === 'top' ? 'active' : ''} aria-current={active === 'top' ? 'location' : undefined} onClick={() => navigate('top')}><span>00</span><div><b>首页</b><small>开始学习</small></div></button>{sections.map(([id, title, question], i) => <button key={id} disabled={i >= visibleCount} className={active === id ? 'active' : progress.visited.includes(id) ? 'visited' : ''} aria-current={active === id ? 'location' : undefined} onClick={() => navigate(id)}><span>§{i + 1}</span><div><b>{title}</b><small>{question.replace(/^\d+\s*·\s*/, '')}</small></div></button>)}<button disabled={!finalVisible} onClick={() => navigate('final')} className={active === 'final' ? 'active' : ''} aria-current={active === 'final' ? 'location' : undefined}><span>终</span><div><b>回顾与自测</b><small>串起整条证据路径</small></div></button></nav>
      <div className="sidebar-tools"><button disabled={!finalVisible} onClick={startReview}>复习全部章节 <ArrowRight size={15}/></button><button onClick={reset}><RotateCcw size={15}/>重新开始</button><a href={PAPER} target="_blank" rel="noreferrer">原始论文 <ExternalLink size={14}/></a></div>
    </aside>
    {mobileOpen && <div className="nav-backdrop" onClick={() => { setMobileOpen(false); menu.current?.focus(); }} aria-hidden="true"/>}
    <main className="tutorial-main" inert={mobileOpen}>
      <section className="hero hero-section" id="top"><div className="hero-inner"><div className="hero-venue">交互式论文教程 · CVPR 2024</div><h1 tabIndex={-1}>V*: Guided Visual Search as a Core Mechanism in Multimodal LLMs</h1><div className="hero-sub"><span>中文教学译名</span>V*：以引导式视觉搜索作为多模态大语言模型的核心机制</div><p className="hero-abs">答案就在图里，但模型真的看见了吗？</p><p className="paper-meta">Penghao Wu · Saining Xie</p><div className="hero-meta" aria-label="论文关键词">{['Multimodal LLM','Guided Visual Search','Visual Working Memory','High-resolution Vision','V*Bench'].map(keyword => <span className="tag" key={keyword}>{keyword}</span>)}</div><div className="hero-links"><a href={PAPER} target="_blank" rel="noreferrer">Paper <ExternalLink size={15}/></a><a href={PDF} target="_blank" rel="noreferrer">PDF <ExternalLink size={15}/></a><a href={CODE} target="_blank" rel="noreferrer">Code <ExternalLink size={15}/></a></div>{visibleCount === 0 && <div className="chap-loader"><div className="chap-loader-hint">从一个杯子的问题开始</div><button className="chap-loader-btn" onClick={start}>开始学习 §1 <span className="chap-loader-arrow">→</span></button></div>}</div></section>
      <div key={epoch}>
        {visibleCount >= 1 && <Chapter index={0} finish={() => advance(0)} source="§1 / Fig. 1" takeaway="关键区别是根据任务主动决定下一步看哪里。" bridge="看不清时，什么时候才需要启动搜索？"><p className="lead">同一道题：杯子里的液体是什么颜色？高分辨率图像缩成全局输入后，小目标细节可能丢失。问题可能出在视觉证据不足，而非语言模型不会推理。</p><DetailLab/></Chapter>}
        {visibleCount >= 2 && <Chapter index={1} finish={() => advance(1)} source="§3.1 / Algorithm 1" takeaway="搜索在当前视觉证据不足时才触发。" bridge="知道要找杯子后，先检查图中哪里？"><p className="lead">Show：VQA LLM 先看问题与全图；信息足够就直接回答，不足才指出缺失目标并进入 Search。沿用杯中液体颜色这个问题。</p><SealPipeline/><DecisionLab/></Chapter>}
        {visibleCount >= 3 && <Chapter index={2} finish={() => advance(2)} source="§3.3.3 / Algorithm 2" takeaway="V* 用目标和上下文线索给区域排序，优先搜索值得看的地方。" bridge="找到杯子之后，怎样用新证据回答？"><p className="lead">Search：目标是杯子。先尝试 target-specific cue；若线索不足，再借助语言模型的场景知识生成 contextual cue。线索热图为 patch 排出优先级，搜索由粗到细推进。</p><SearchLab/></Chapter>}
        {visibleCount >= 4 && <Chapter index={3} finish={() => advance(3)} source="§3.1 / Algorithm 1" takeaway="VWM 保留任务、全局上下文、局部细节与目标位置，再交给 VQA LLM 作答。" bridge="这条证据路径怎样接受实验检验？"><p className="lead">TelL：只看杯子的 crop 会丢掉它与全图的关系。Visual Working Memory 把 Question、Global Image、Searched Target 和 Target Location 组织为工作输入，再 tokenize 并交给 VQA LLM 回答。</p><CupMemoryLab/></Chapter>}
        {visibleCount >= 5 && <Chapter index={4} finish={() => advance(4)} source="§4–5 / Tables 1–3" takeaway="V*Bench 测试能否找到关键细节再回答；论文实验支持显式视觉搜索在这类场景中的价值。" bridge="这些结果把 MLLM 的视觉能力推进到哪里？"><p className="lead">研究问题：现有基准若很少要求定位细小目标，就难以检验搜索。作者构建 V*Bench：191 张高分辨率图像，包含 115 道属性识别问题和 76 道空间关系推理问题，面向视觉拥挤且需要精细定位的场景。</p><div className="bench-intro"><div><span className="eyebrow">任务 A · 115</span><strong>属性识别</strong><p>寻找目标并判断属性；杯中颜色是贯穿前四章的教学示意。</p></div><div><span className="eyebrow">任务 B · 76</span><strong>空间关系</strong><p>定位两个目标，判断相对位置。</p></div></div><p className="lead">实验依次比较主结果、搜索替换消融与线索对搜索效率的影响。结果只支持论文给定数据、模型和评价设置下的结论。</p><Results/></Chapter>}
        {visibleCount >= 6 && <Chapter index={5} finish={() => advance(5)} source="§1 / §6 / Table 5" takeaway="V* 将固定视觉输入推进到任务驱动的主动视觉搜索。" bridge="如果输入变成视频，模型能否决定什么时候再看一次？"><p className="lead">传统流程是 Observation → Reasoning → Answer。V* 在需要时插入 Search Action → New Observation，再继续推理与回答。</p><div className="synthesis-line"><span>观察</span><span>推理</span><span>搜索动作</span><span>新观察</span><span>再推理</span><span>回答</span></div><h3>推进了什么</h3><ol className="contribution-list"><li>视觉输入可以随任务补充，不再完全固定。</li><li>语言推理开始引导下一步视觉信息获取。</li><li>模型能主动补充缺失的视觉证据；V*Bench 为此提供了专门检验。</li></ol><h3>研究边界</h3><ul className="limits"><li>论文没有解决长时序视频观察与更一般的 observation planning。</li><li>完整的 evidence sufficiency、显式 stopping loop 和复杂成本约束仍值得继续研究。</li><li>搜索有计算成本；通用基准也并非全部提升。（§5.1 / §5.4）</li></ul><p className="next-paper">如果输入不再是一张图，而是一段视频，模型能不能在推理过程中自己决定什么时候需要再看一次？<strong>Next: Act2See →</strong></p></Chapter>}
        {finalVisible && <section id="final" className="final" aria-labelledby="final-title"><span className="section-kicker">FINAL · 回顾</span><h2 id="final-title" tabIndex={-1}>从看图，到主动寻找证据</h2><ol className="takeaways"><li>视觉信息不足时，先指出缺失目标。</li><li>V* 用任务和上下文线索引导搜索。</li><li>VWM 把局部证据与全图一起交回回答模型。</li></ol><FinalQuiz/><div className="final-actions"><button className="button-primary" onClick={startReview}>复习全部章节 <ArrowRight size={17}/></button><button className="button-outline" onClick={reset}><RotateCcw size={16}/>重新开始</button></div></section>}
      </div>
    </main>
  </div>;
}
